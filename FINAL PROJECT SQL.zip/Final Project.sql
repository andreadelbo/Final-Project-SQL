/* Crea e popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate).
 Dopo la creazione e l’inserimento dei dati nelle tabelle, esegui e riporta delle query utili a: 
 1. Verificare che i campi definiti come PK siano univoci. 
 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). */

create DATABASE final_project;

USE final_project;

CREATE TABLE Product ( 
		product_key INT primary key auto_increment, 
        product_name VARCHAR(50) not null, 
        price DECIMAL(10,2) not null,
        category varchar(50) not null,
        quantity INT not null 
        ) 
;

CREATE TABLE Sales ( 
		sales_id INT PRIMARY KEY, 
        sales_date date not null, 
        sales_quantity INT not null,
        product_key INT, 
        foreign key (product_key) references Product(product_key)
        ) ;

;

CREATE TABLE Region ( 
		region_id INT PRIMARY KEY, 
        region_name varchar(30) not null, 
        sales_id INT, 
        foreign key (sales_id) references Sales(sales_id)
        ) 
;


INSERT INTO Product (product_name, price, category, quantity) 
VALUES ('Laptop', 999.99, 'Electronics', 50), ('T-shirt', 19.99, 'Clothing', 100), ('Headphones', 49.99, 'Electronics', 30), ('Sneakers', 79.99, 'Footwear', 75), ('Coffee Maker', 29.99, 'Appliances', 25);
select * from product;

INSERT INTO Sales (sales_id, sales_date, sales_quantity, product_key) 
VALUES (1001,'2021-01-15', 3, 1), (1002,'2021-01-16', 2, 2), (1003,'2021-01-17', 1, 2), (1004,'2021-01-18', 5, 4), (1005,'2021-01-19', 4, 1);

select * from sales;

INSERT INTO Region (region_id, region_name, sales_id) 
VALUES (11, 'North America', 1001), (12,'Europe', 1002), (13,'Asia', 1003), (14, 'Australia', 1004), (15, 'Africa', 1005);

select * from Region;


-- 1. Verificare che i campi definiti come PK siano univoci. --
select * from product;
select * from sales;
select * from Region;

 -- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. --
 SELECT p.product_name, 
 YEAR(s.sales_date) as sales_year, 
 SUM(p.price * s.sales_quantity) as total_revenue 
 FROM Product p 
 JOIN Sales s 
 ON p.product_key = s.product_key 
 GROUP BY p.product_name, sales_year;
 
 -- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. --
 SELECT r.region_name, 
 YEAR(s.sales_date) as year, 
 SUM(p.price * s.sales_quantity) as total_revenue 
 FROM Region r 
 JOIN Sales s ON r.sales_id = s.sales_id 
 JOIN Product p ON s.product_key = p.product_key 
 GROUP BY r.region_name, 
 year ORDER BY year, 
 total_revenue DESC;
 
--  4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? --
SELECT category, 
SUM(sales_quantity) as total_sales
FROM Product as p
JOIN Sales as s ON p.product_key = s.product_key
GROUP BY category
ORDER BY total_sales DESC
LIMIT 1;

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. --
SELECT product_name 
FROM Product 
WHERE product_key NOT IN (
				SELECT product_key 
                FROM Sales
                )
;
select p.product_name
from Product as p
left join Sales as s on p.product_key = s.product_key
where sales_id is null 
and  p.product_name is not null
;

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). --
select  p.product_name,
		max(s.sales_date) as last_date_sales
from Product as p
join Sales as s on p.product_key = s.product_key
group by p.product_name
;